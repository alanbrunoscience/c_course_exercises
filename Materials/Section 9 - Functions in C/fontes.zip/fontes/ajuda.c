void mensagem(){
	printf("Bem-vindo...\n");
}

int soma(int num1, int num2){
	return num1 + num2;
}

int multiplicacao(int num1, int num2){
	return num1 * num2;
}
