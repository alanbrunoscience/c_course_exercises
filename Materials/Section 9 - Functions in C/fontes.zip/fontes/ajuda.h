void mensagem();
int soma(int num1, int num2);
int multiplicacao(int num1, int num2);
