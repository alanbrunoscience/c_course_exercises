//Aula sobre variáveis
#include <stdio.h>

int main(){ //a chave delimita um bloco de código (início do bloco)
	//declarando variáveis
	int idade; //inteiro

	declarando e inicializando variáveis
	//int idade = 0;

	//função para escrever algo na saída padrão (console)
	printf("Qual é a sua idade? "); //o ponto e vírgula finaliza um comando

	//Receber dados
	scanf("%d", &idade);

	return 0;
} //fim do bloco