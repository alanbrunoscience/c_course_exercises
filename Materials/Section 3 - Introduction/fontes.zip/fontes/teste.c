#include <stdio.h>

// principal -> main
int main(){
	printf("Geek University!");

	return 0;
}