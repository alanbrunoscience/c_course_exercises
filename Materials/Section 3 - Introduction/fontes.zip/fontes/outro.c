#include <stdio.h>

//outro arquivo
int main(){
	printf("Outro");

	return 0;
}